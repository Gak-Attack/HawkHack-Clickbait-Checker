package clickbaitChecker;

public class wordCount {
	String word;
	int count = 0;
	
	public wordCount (final String word) {
		
		this.word = word;
	}
	
	
	/*
	 * Returns the string associated with the word.
	 * Returns:
	 * 	word
	 */
	public String getWord () {
		return this.word;
	}
	
	
	/*
	 * Returns the count associated with the word.
	 * Returns:
	 * 	count
	 */
	public int getCount () {
		return this.count;
	}
	
	/*
	 * Increases the count of the word by one, then returns it.
	 * Returns:
	 * 	count
	 */
	public int increaseCount () {
		this.count++;
		return this.count;
	}
	
	/*
	 * Decreases the count of the word by one, then returns it.
	 * Returns:
	 * 	count
	 */
	public int decreaseCount () {
		this.count--;
		return this.count;
	}
	
	
	/*
	 * Shows the String and Count associated with the wordCount object as a String
	 */
	public String toString () {
		return ("Word: "+this.word + "\nCount: "+this.count +".\n");
	}
}
