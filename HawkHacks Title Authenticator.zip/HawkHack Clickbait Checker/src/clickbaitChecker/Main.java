package clickbaitChecker;

import java.io.FileReader;
import java.util.Scanner;

public class Main {
	static String title = "";
	static String text = "";
	static int keywordCount = 0;
	
	public static void main(String[] args) {
		
		//Reads a text file, and puts it into a string
		try {
			//inputs title
			Scanner input =  new Scanner(System.in);
			System.out.println("Enter a title to check:");
			title = input.nextLine();
			
			//inputs text file title to read
			System.out.println("Enter the file to read (fo not include .txt):");
			String file = input.nextLine();
			
			//Reads file, and sends the text to text
			
			Scanner fileReader = new Scanner(new FileReader(file+".txt"));
			text = fileReader.nextLine();
			while(fileReader.hasNext()) {
				text = text + " "+ fileReader.nextLine();
			}
		} catch (Exception e) {
			System.out.println("problem found");
			//Lets us know if the file reading doesn't work
		}
		
		
		String [] text_list = to_list(text);
		String [] title_list = to_list(title);
		//converts the strings into the componant words
		
		wordCount[] title_wrd = str_to_wordCount(title_list);
		//converts the title into wordCounts, a data type that has a count to go along with the word.
		
		count_words (title_wrd, text_list);
		//counts the amount of the title words in the text
		
		for(int i = 0; i<title_wrd.length; i++) {
			System.out.println(title_wrd[i].toString());
			if(title_wrd[i].getWord().length() != 1) {
				keywordCount+=title_wrd[i].getCount();
			}
		}
		//adds all the word counts to determine the % of words in the text are in the title
		
		
		System.out.println("There are "+keywordCount+ " title words, and "+text_list.length +" words in the entire text file.");
		
		
		//prints out the amount of text in the file is in the title (ex. 7% accurate)
		System.out.println("The title is about " + (keywordCount*100/(text_list.length)) + "% of the text.");
		
		//prints out if the title is accurate or not based on the amount the percent from above without mentioning how accurate it is.
		
	}
	/*
	 * Param:
	 * str_list: the list of strings 
	 */
	private static wordCount[] str_to_wordCount (String[] str_list){
		
		wordCount[] wrd_list = new wordCount[str_list.length];
		for(int i = 0; i<str_list.length; i++) {
			wrd_list[i] = new wordCount(str_list[i]);
		}
		//fills a new list of wordCount with the strings in str_list
		
		return wrd_list;
	}
	
	/*
	 * Param:
	 * str: a string to remove punctuation and split among the spaces
	 */
	private static String[] to_list (String str) {
		str = str.replace("."," ");
		str = str.replace(","," ");
		str = str.replace(";"," ");
		str = str.replace(":"," ");
		str = str.replace(")"," ");
		str = str.replace("("," ");
		str = str.replace("'"," ");
		str = str.replace("?"," ");
		str = str.replace("  "," ");
		//gets rid of the punctuation in a string
		String[] str_list = str.split(" ");
		//Splits the string into the individual words
		for(int i = 0; i<str_list.length; i++) {
			str_list[i] = str_list[i].toLowerCase();
			//sets the words to lowercase
		}
		return str_list;
	}
	
	
	//Goes through the entire list of words, and checks if the title words are in there. O((length of title)*(length of text))
	/*
	 * Parameters:
	 * Title: the list of words in the title, with all counts at 0
	 * text:the contents of the text file in as words in a list of strings
	 */
	private static void count_words (wordCount[] title, String[] text) {
		for(int i = 0; i<text.length; i++) {
			for(int j = 0; j<title.length; j++) {
				if(title[j].word.equals(text[i])) {
					title[j].count++;
				}
			}
		}
		return;
	}
}
