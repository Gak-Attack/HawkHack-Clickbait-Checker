package clickbaitChecker;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
	static String title = "";
	static String transcript = "";
	static int keywordCount;
	
	public static void main(String[] args) {
		
		//Reads a text file, and puts it into a string
		try {
			//inputs title
			Scanner input =  new Scanner(System.in);
			System.out.println("Enter a title to check:");
			title = input.nextLine();
			
			//inputs text file title to read
			System.out.println("Enter the file to read (not including .txt):");
			String file = input.nextLine();
			
			//Reads file, and sends the text to transcript
			
			Scanner fileReader = new Scanner(new FileReader(file+".txt"));
			transcript = fileReader.nextLine();
			while(fileReader.hasNext()) {
				transcript = transcript + " "+ fileReader.nextLine();
			}
			System.out.println(transcript);
		} catch (Exception e) {
			System.out.println("problem found");
			//Lets us know if the file reading doesn't work
		}
		
		
		String [] trans_list = to_list(transcript);
		String [] title_list = to_list(title);
		//converts the strings into the componant words
		
		wordCount[] title_wrd = str_to_wordCount(title_list);
		//converts the title into wordCounts, a data type that has a count to go along with the word.
		
		count_words (title_wrd, trans_list);
		//counts the amount of the title words in the transcript
		
		for(int i = 0; i<title_wrd.length; i++) {
			System.out.println(title_wrd[i].toString());
			if(title_wrd[i].getWord().length() != 1) {
				keywordCount+=title_wrd[i].count;
			}
		}
		//adds all the word counts to determine the % of words in the transcript are in the title
		
		
		System.out.println("There are "+keywordCount+ " title words, and "+trans_list.length +" words in the entire text file.");
		
		
		if(keywordCount*100/(trans_list.length)<3) {
			System.out.println("The title is not accurate");
			//less than n% of the words are in the title and transcript, not accurate
		}
		else {
			System.out.println("The title is accurate");
			//more than n% of the words are in the title and transcript, accurate
		}
		
	}
	private static wordCount[] str_to_wordCount (String[] str_list){
		
		wordCount[] wrd_list = new wordCount[str_list.length];
		for(int i = 0; i<str_list.length; i++) {
			wrd_list[i] = new wordCount(str_list[i]);
		}
		//fills a new list of wordCount with the strings in str_list
		
		return wrd_list;
	}
	
	
	private static String[] to_list (String str) {
		str = str.replace("."," ");
		str = str.replace(","," ");
		str = str.replace(";"," ");
		str = str.replace(":"," ");
		str = str.replace(")"," ");
		str = str.replace("("," ");
		str = str.replace("'"," ");
		str = str.replace("?"," ");
		//gets rid of the punctuation in a string
		String[] str_list = str.split(" ");
		//Splits the string into the individual words
		for(int i = 0; i<str_list.length; i++) {
			str_list[i] = str_list[i].toLowerCase();
			//sets the words to lowercase
		}
		return str_list;
	}
	
	private static void count_words (wordCount[] title, String[] transcript) {
		for(int i = 0; i<transcript.length; i++) {
			for(int j = 0; j<title.length; j++) {
				if(title[j].word.equals(transcript[i])) {
					title[j].count++;
				}
				//Goes through the entire list of words, and checks if the title words are in there. O(n*k)
			}
		}
		return;
	}
}
