package clickbaitChecker;

public class wordCount {
	String word;
	int count = 0;
	
	public wordCount (final String word) {
		
		this.word = word;
	}
	
	public String getWord () {
		return this.word;
	}
	
	public int getCount () {
		return this.count;
	}
	public String toString () {
		return ("The current word is "+this.word + ", and the current count is "+this.count +".");
	}
}
